from . import index


def run():
    index.main()
